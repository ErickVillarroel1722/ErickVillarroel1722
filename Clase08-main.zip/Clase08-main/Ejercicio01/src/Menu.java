public class Menu {
    public static void main(String[] args) {

        //Objetos
       Ana persona1 = new Ana(
                "Anna",
                "Leo",
                "33");

       Pablo persona2 = new Pablo(
               "Pablo",
               "17227955",
               "Empleado Publico");

       Maritza persona3 = new Maritza(
               "Maritza",
               "Corredora"
               );

       Melani persona4 = new Melani(
           "Melani",
           "Estudiante",
           "Tercer semestre");

       //Llamada de objetos
        persona1.examinar();
        System.out.println("****************************************************************");

        persona2.tramitar();
        System.out.println("****************************************************************");

        persona3.correr();
        System.out.println("****************************************************************");

        persona4.leer();
        System.out.println("****************************************************************");
    }
}
