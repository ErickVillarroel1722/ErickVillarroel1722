//Metodo Persona
public class Ana{

    /******************************************************************************************/

    //Atributos
    private String nombre;
    private String signo;
    private String edad;

    /******************************************************************************************/

    //Metodos
    //Constructor
    public Ana(String nombre, String signo, String edad) {
        this.nombre = nombre;
        this.signo = signo;
        this.edad = edad;
    }

    /******************************************************************************************/

    //Acciones
    public void examinar(){
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Signo: " + this.signo);
        System.out.println("Edad: " + this.edad);
        System.out.println("Me dedidco a examinar");
        }

    /******************************************************************************************/

}
