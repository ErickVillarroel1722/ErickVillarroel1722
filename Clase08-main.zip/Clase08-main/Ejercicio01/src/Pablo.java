//Metodo Persona
public class Pablo{

    /******************************************************************************************/

    //Atributos
    private String nombre;
    private String telefono;
    private String profesion;

    /******************************************************************************************/

    //Metodos
    //Constructor
    public Pablo(String nombre, String telefono, String profesion) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.profesion = profesion;
    }

    /******************************************************************************************/

    //Acciones
    public void tramitar(){
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Telefono: " + this.telefono);
        System.out.println("Profesion: " + this.profesion);
        System.out.println("Me dedidco a tramitar");
    }

    /******************************************************************************************/

}
