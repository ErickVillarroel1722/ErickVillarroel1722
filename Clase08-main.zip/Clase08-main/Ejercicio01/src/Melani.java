//Metodo Persona
public class Melani{

    /******************************************************************************************/

    //Atributos
    private String nombre;
    private String ocupacion;
    private String semestre;

    /******************************************************************************************/

    //Metodos
    //Constructor
    public Melani(String nombre, String ocupacion, String semestre) {
        this.nombre = nombre;
        this.ocupacion = ocupacion;
        this.semestre = semestre;
    }

    /******************************************************************************************/
    //Acciones
    public void leer(){
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Ocupacion: " + this.ocupacion);
        System.out.println("Semestre: " + this.semestre);
        System.out.println("Me dedico a leer");
    }
    /******************************************************************************************/

}
