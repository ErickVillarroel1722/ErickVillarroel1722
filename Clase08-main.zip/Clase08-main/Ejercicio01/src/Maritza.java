//Metodo Persona
public class Maritza{

    /******************************************************************************************/

    //Atributos
    private String nombre;
    private String profesion;

    /******************************************************************************************/

    //Metodos
    //Constructor
    public Maritza(String nombre, String profesion) {
        this.nombre = nombre;
        this.profesion = profesion;
    }

    /******************************************************************************************/
    //Acciones
    public void correr(){
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Profesion: " + this.profesion);
        System.out.println("Me dedidco a correr 5 km todos los dias");
    }
    /******************************************************************************************/

}
